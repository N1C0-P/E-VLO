﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int dice1, dice2, dice3, dice4, dice5, sum;

        private void zbierzKościToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            pictureBox2.Image = null;
            pictureBox3.Image = null;
            pictureBox4.Image = null;
            pictureBox5.Image = null;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Czy na pewno chcesz wyłączyć aplikację Kości ?", "Exit", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else if (dialog == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.PerformClick();

        }

        private void wyczyśćTabelkęToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Aplikacja rzucająca Kośćmi \n\nAutor:\n     Nikodem Popławski");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            dice1 = rnd.Next(1, 7);
            dice2 = rnd.Next(1, 7);
            dice3 = rnd.Next(1, 7);
            dice4 = rnd.Next(1, 7);
            dice5 = rnd.Next(1, 7);

            sum = dice1 + dice2 + dice3 + dice4 + dice5;


            switch (dice1)
            {
                case 1:
                    pictureBox1.Image = Properties.Resources.D1;
                    break;
                case 2:
                    pictureBox1.Image = Properties.Resources.D2;
                    break;
                case 3:
                    pictureBox1.Image = Properties.Resources.D3;
                    break;
                case 4:
                    pictureBox1.Image = Properties.Resources.D4;
                    break;
                case 5:
                    pictureBox1.Image = Properties.Resources.D5;
                    break;
                case 6:
                    pictureBox1.Image = Properties.Resources.D6;
                    break;
            }
            switch (dice2)
            {
                case 1:
                    pictureBox2.Image = Properties.Resources.D1;
                    break;
                case 2:
                    pictureBox2.Image = Properties.Resources.D2;
                    break;
                case 3:
                    pictureBox2.Image = Properties.Resources.D3;
                    break;
                case 4:
                    pictureBox2.Image = Properties.Resources.D4;
                    break;
                case 5:
                    pictureBox2.Image = Properties.Resources.D5;
                    break;
                case 6:
                    pictureBox2.Image = Properties.Resources.D6;
                    break;
            }
            switch (dice3)
            {
                case 1:
                    pictureBox3.Image = Properties.Resources.D1;
                    break;
                case 2:
                    pictureBox3.Image = Properties.Resources.D2;
                    break;
                case 3:
                    pictureBox3.Image = Properties.Resources.D3;
                    break;
                case 4:
                    pictureBox3.Image = Properties.Resources.D4;
                    break;
                case 5:
                    pictureBox3.Image = Properties.Resources.D5;
                    break;
                case 6:
                    pictureBox3.Image = Properties.Resources.D6;
                    break;
            }
            switch (dice4)
            {
                case 1:
                    pictureBox4.Image = Properties.Resources.D1;
                    break;
                case 2:
                    pictureBox4.Image = Properties.Resources.D2;
                    break;
                case 3:
                    pictureBox4.Image = Properties.Resources.D3;
                    break;
                case 4:
                    pictureBox4.Image = Properties.Resources.D4;
                    break;
                case 5:
                    pictureBox4.Image = Properties.Resources.D5;
                    break;
                case 6:
                    pictureBox4.Image = Properties.Resources.D6;
                    break;
            }
            switch (dice5)
            {
                case 1:
                    pictureBox5.Image = Properties.Resources.D1;
                    break;
                case 2:
                    pictureBox5.Image = Properties.Resources.D2;
                    break;
                case 3:
                    pictureBox5.Image = Properties.Resources.D3;
                    break;
                case 4:
                    pictureBox5.Image = Properties.Resources.D4;
                    break;
                case 5:
                    pictureBox5.Image = Properties.Resources.D5;
                    break;
                case 6:
                    pictureBox5.Image = Properties.Resources.D6;
                    break;
            }
            textBox1.AppendText(" Wynik: " + dice1 + " | " + dice2 + " | " + dice3 + " | " + dice4 + " | " + dice5 + "  |  Łącznie: " + sum + Environment.NewLine +"---------------------------------------------------------" + Environment.NewLine);
        }
    }
}
